<?php
/*
Plugin Name:  newtheme newtheme
Plugin URI:   
Description:  Adding Metaboxes for newtheme
Version:      1.0.0
Author:       Ali Alaa
Author URI:   http://alialaa.com/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  newtheme-newtheme
Domain Path:  /languages
*/

if( !defined('WPINC')) {
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');